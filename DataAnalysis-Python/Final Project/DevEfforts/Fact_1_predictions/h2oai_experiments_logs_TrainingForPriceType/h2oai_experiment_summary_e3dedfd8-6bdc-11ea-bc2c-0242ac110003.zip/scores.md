### Model and feature tuning leaderboard (scorer=GINI):

| model_class_name   | model_origin                                               |    scores |   scores_sd |   tournament scores |   rel_scores |   rel_tournament scores |   nfeatures |   feature cost |   job order | job status   | booster   | boosting_type   |   colsample_bytree | disable_gpus   |   early_stopping_rounds | enable_early_stopping_rounds   |   ensemble_level | eval_metric   |   gamma | grow_policy   |   interpretability |   learning_rate | lossguide   |   max_bin |   max_delta_step |   max_depth |   max_leaves | min_child_samples   |   min_child_weight | min_data_in_bin   |   n_estimators |   n_jobs |   num_class |   num_classes | objective      | pred_gap   | pred_periods   |   random_state |   reg_alpha |   reg_lambda |   scale_pos_weight |       seed |   subsample | train_shape   | tree_method   | valid_shape   |   training_times |   best_iterations | transformers_used                                                                                  | from_brain   | derived_from_brain   |   from_brain_count |   derived_from_brain_count | isbest   | good   |
|:-------------------|:-----------------------------------------------------------|----------:|------------:|--------------------:|-------------:|------------------------:|------------:|---------------:|------------:|:-------------|:----------|:----------------|-------------------:|:---------------|------------------------:|:-------------------------------|-----------------:|:--------------|--------:|:--------------|-------------------:|----------------:|:------------|----------:|-----------------:|------------:|-------------:|:--------------------|-------------------:|:------------------|---------------:|---------:|------------:|--------------:|:---------------|:-----------|:---------------|---------------:|------------:|-------------:|-------------------:|-----------:|------------:|:--------------|:--------------|:--------------|-----------------:|------------------:|:---------------------------------------------------------------------------------------------------|:-------------|:---------------------|-------------------:|---------------------------:|:---------|:-------|
| LightGBMModel      | DefaultIndiv: do_te:only,interp:5,depth:6,num_as_cat:False | 0.8777703 | 0.002497881 |           0.8777703 |    1         |               1         |          82 |             82 |           2 | PASSED       | lightgbm  | gbdt            |                0.8 | False          |                      20 | True                           |                1 | mlogloss      |       0 | depthwise     |                  5 |             0.1 | False       |       256 |                0 |           6 |            0 | 1                   |                  1 | 1                 |            300 |        2 |           3 |             3 | multi:softprob |            |                |      254274048 |           0 |            1 |                  1 |  254274048 |         0.7 | (35672, 28)   | gpu_hist      |               |       10.06393   |               164 | ['CVTargetEncodeTransformer', 'InteractionsTransformer', 'OriginalTransformer', 'TextTransformer'] | False        | False                |                  0 |                          0 |          | +      |
| LightGBMModel      | SEQUENCE                                                   | 0.8774027 | 0.002417752 |           0.8774027 |    0.9995813 |               0.9995813 |          32 |             32 |           0 | PASSED       | lightgbm  | gbdt            |                0.8 | False          |                      20 | True                           |                1 | mlogloss      |       0 | depthwise     |                  5 |             0.1 | False       |       256 |                0 |           6 |            0 | 1                   |                  1 | 1                 |            300 |        2 |           3 |             3 | multi:softprob |            |                |      254274048 |           0 |            1 |                  1 |  254274048 |         0.7 | (35672, 28)   | gpu_hist      |               |        7.854527  |               136 | ['CVTargetEncodeTransformer', 'OriginalTransformer']                                               | False        | False                |                  0 |                          0 | *        | +      |
| XGBoostGBMModel    | SEQUENCE                                                   | 0.8759581 | 0.002129722 |           0.8759581 |    0.9979355 |               0.9979355 |          32 |             32 |           1 | PASSED       | gbtree    |                 |                0.8 | False          |                      20 |                                |                1 | mlogloss      |       0 | depthwise     |                  5 |             0.1 | False       |       256 |                0 |           6 |            0 |                     |                  1 |                   |            300 |        2 |           3 |             3 | multi:softprob |            |                |      254274048 |           0 |            1 |                  1 |  254274048 |         0.7 | (35672, 28)   | gpu_hist      |               |       19.72036   |               157 | ['CVTargetEncodeTransformer', 'OriginalTransformer']                                               | False        | False                |                  0 |                          0 |          | +      |
| ConstantModel      | REF_0                                                      | 0.4599277 | 0.004646697 |           0.4599277 |    0.5239727 |               0.5239727 |           1 |              1 |           3 | PASSED       | constant  | gbdt            |                0.8 | False          |                      20 | True                           |                1 | mlogloss      |       0 | depthwise     |                  5 |             0.1 | False       |       256 |                0 |           6 |            0 | 1                   |                  1 | 1                 |            300 |        2 |           3 |             3 | multi:softprob |            |                |     1011415184 |           0 |            1 |                  1 | 1011415184 |         0.7 | (35672, 28)   | gpu_hist      |               |        0.2421017 |                 1 | ['OriginalTransformer']                                                                            | False        | False                |                  0 |                          0 |          |        |

* [tuning_leaderboard_simple.json](/files/h2oai_experiment_e3dedfd8-6bdc-11ea-bc2c-0242ac110003/tuning_leaderboard_simple.json) (also in summary .zip)
---


### Single final model cross-validation fold scores (ConstantModel added for reference only, will be dropped in most cases):

| model_name    |   model_id |   fold_id |   ACCURACY |       AUC |     AUCPR |       F05 |        F1 |        F2 |      GINI |   LOGLOSS |   MACROAUC |       MCC |
|:--------------|-----------:|----------:|-----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|-----------:|----------:|
| LightGBMModel |          0 |         0 |  0.8017715 | 0.9390106 | 0.8810558 | 0.8017715 | 0.8017715 | 0.8017715 | 0.8780212 | 0.4574947 |  0.918735  | 0.7026572 |
| LightGBMModel |          0 |         1 |  0.8029827 | 0.9393508 | 0.8805967 | 0.8029827 | 0.8029827 | 0.8029827 | 0.8787016 | 0.4566086 |  0.9199596 | 0.7044741 |
| LightGBMModel |          0 |         2 |  0.7993945 | 0.9371814 | 0.8783756 | 0.7993945 | 0.7993945 | 0.7993945 | 0.8743627 | 0.4664401 |  0.9151349 | 0.6990917 |
| LightGBMModel |          0 |         3 |  0.8049793 | 0.9402734 | 0.8849582 | 0.8049793 | 0.8049793 | 0.8049793 | 0.8805468 | 0.4523723 |  0.9204226 | 0.7074689 |
| ConstantModel |          1 |         0 |  0.5141832 | 0.7299585 | 0.4865391 | 0.5141832 | 0.5141832 | 0.7142857 | 0.459917  | 0.8628083 |  0.5       | 0.2712748 |
| ConstantModel |          1 |         1 |  0.5141287 | 0.7299282 | 0.4865067 | 0.5141287 | 0.5141287 | 0.7142857 | 0.4598565 | 0.8628304 |  0.5       | 0.2711931 |
| ConstantModel |          1 |         2 |  0.5141287 | 0.7299282 | 0.4865067 | 0.5141287 | 0.5141287 | 0.7142857 | 0.4598565 | 0.8628304 |  0.5       | 0.2711931 |
| ConstantModel |          1 |         3 |  0.5141864 | 0.7300101 | 0.4865764 | 0.5141864 | 0.5141864 | 0.7142857 | 0.4600202 | 0.8626003 |  0.5       | 0.2712796 |

* [ensemble_base_learner_fold_scores.json](/files/h2oai_experiment_e3dedfd8-6bdc-11ea-bc2c-0242ac110003/ensemble_base_learner_fold_scores.json) (also in summary .zip)
---


### Pipeline Description:

|   Model Weight | model_class_name   |   Fitted features | Type          |   Num Folds | booster   |   max_depth |   max_leaves |   subsample |   colsample_bytree | tree_method   | grow_policy   |   random_state |   learning rate | Target Transformer   | Fit iterations [each fold]   |
|---------------:|:-------------------|------------------:|:--------------|------------:|:----------|------------:|-------------:|------------:|-------------------:|:--------------|:--------------|---------------:|----------------:|:---------------------|:-----------------------------|
|              1 | LightGBMModel      |                65 | LightGBMModel |           4 | lightgbm  |           6 |           64 |         0.7 |                0.8 | gpu_hist      | depthwise     |      254274048 |            0.05 | LabelEncoder         | [320]                        |

* [ensemble_model_description.json](/files/h2oai_experiment_e3dedfd8-6bdc-11ea-bc2c-0242ac110003/ensemble_model_description.json) (also in summary .zip)
---


### Final Ensemble Scores:

| Scorer   | Better score is   | Final ensemble scores +/- standard deviation on validation (internal or external holdout(s)) data   | Optimized   |
|:---------|:------------------|:----------------------------------------------------------------------------------------------------|:------------|
| MCC      | higher            | 0.7034229 +/- 0.002248626                                                                           |             |
| MACROAUC | higher            | 0.9185 +/- 0.001168665                                                                              |             |
| LOGLOSS  | lower             | 0.4582291 +/- 0.002811727                                                                           |             |
| F2       | higher            | 0.8022819 +/- 0.001499084                                                                           |             |
| F1       | higher            | 0.8022819 +/- 0.001499084                                                                           |             |
| F05      | higher            | 0.8022819 +/- 0.001499084                                                                           |             |
| AUCPR    | higher            | 0.8811375 +/- 0.001282114                                                                           |             |
| AUC      | higher            | 0.9389417 +/- 0.0006388605                                                                          |             |
| ACCURACY | higher            | 0.8022819 +/- 0.001499084                                                                           |             |
| GINI     | higher            | 0.8778835 +/- 0.001277721                                                                           | *           |

* [ensemble_scores.json](/files/h2oai_experiment_e3dedfd8-6bdc-11ea-bc2c-0242ac110003/ensemble_scores.json) (also in summary .zip)
---


